/*eslint-disable*/
const zh_CN = {

};
export default zh_CN;
