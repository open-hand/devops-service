# To customize a template
you need to push the template code to this git repository.

Please make sure the following file exists.
+ **gitlab-ci.yml**. (Refer to [GitLab Documentation](https://docs.gitlab.com/ee/ci/yaml/))
+ **Dockerfile**. (Refer to [Dockerfile reference](https://docs.docker.com/engine/reference/builder/))
+ **Chart** setting directory. (Refer to [helm](https://github.com/kubernetes/helm))

Finally, removing or re-editing this **README.md** file to make it useful.
