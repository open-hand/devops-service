package io.choerodon.lib;

public class TestDriver {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}