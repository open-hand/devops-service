# {{service.code}}

This is a choerodon front template.