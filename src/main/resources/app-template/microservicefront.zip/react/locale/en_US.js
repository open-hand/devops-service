const enUS = {

};
export default enUS;