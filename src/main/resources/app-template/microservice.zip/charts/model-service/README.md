# Quick start

部署文件的渲染模板，我们下文将定义一些变量，helm执行时会将变量渲染进模板文件中。

## readinessProbe探针

设置curl 访问/health端口和服务端口，在两个都通的情况下pod才为ready

## _helpers.tpl

这个文件我们用来进行标签模板的定义，以便在上文提到的位置进行标签渲染。

标签总共分为三个部分: 平台、微服务、监控。

### 平台标签

#### deployment 级:

```
{{- define "service.labels.standard" -}}
choerodon.io/release: {{ .Release.Name | quote }}
{{- end -}}
```
平台管理实例需要的实例ID。

### 微服务标签

#### pod 级:

```
{{- define "service.microservice.labels" -}}
choerodon.io/version: {{ .Chart.Version | quote }}
choerodon.io/service: {{ .Chart.Name | quote }}
choerodon.io/metrics-port: {{ .Values.deployment.managementPort | quote }}
{{- end -}}
```
微服务注册中心进行识别时所需要的版本号、项目名称、管理端口。

### 监控和日志标签

#### deployment 级:

```
{{- define "service.logging.deployment.label" -}}
choerodon.io/logs-parser: {{ .Values.logs.parser | quote }}
{{- end -}}
```
日志管理所需要的应用标签。该标签指定应用程序的日志格式，内置格式有`nginx`,`spring-boot`,`docker`对于spring-boot微服务请使用`spring-boot`，如果不需要收集日志请移除此段代码，并删除模板文件关于`service.logging.deployment.label`的引用。

#### pod 级:

```
{{- define "service.monitoring.pod.annotations" -}}
choerodon.io/metrics-group: {{ .Values.metrics.group | quote }}
choerodon.io/metrics-path: {{ .Values.metrics.path | quote }}
{{- end -}}
```
性能指标管理所需要的应用类别以及监控指标路径。其中`metrics-group`将应用按照某个关键字分组，并在grafana配置实现分组展示。`metrics-path`指定收集应用的指标数据路径。
如果不需要监控请移除此段代码

## values.yaml

这个文件中的键值对，即为我们上文中所引用的变量。

将所有变量集中在一个文件中，方便部署的时候进行归档以及灵活替换。

同时，helm命令支持使用 `--set FOO_BAR=FOOBAR` 参数对values 文件中的变量进行赋值，可以进一步简化部署流程。


## 参数对照表

参数名 | 含义 
--- |  --- 
replicaCount | pod运行数量
image.repository | 镜像库地址
image.pullPolicy | 镜像拉取策略
preJob.timeout | job超时时间
preJob.image | job镜像库地址
preJob.preConfig.enabled | 是否初始manager_service数据库
preJob.preConfig.configFile | 初始化到配置中心文件名
preJob.preConfig.configType | 初始化到配置中心存储方式
preJob.preConfig.registerHost | 注册中心地址
preJob.preConfig.datasource.url | manager_service数据库连接地址
preJob.preConfig.datasource.username | manager_service数据库用户名
preJob.preConfig.datasource.password | manager_service数据库密码
preJob.preInitDB.enabled | 是否初始demo_service数据库
preJob.preInitDB.datasource.url | demo_service数据库连接地址
preJob.preInitDB.datasource.username | demo_service数据库用户名
preJob.preInitDB.datasource.password | demo_service数据库密码
deployment.managementPort | 服务管理端口
env.open.EUREKA_CLIENT_SERVICEURL_DEFAULTZONE | 注册服务地址
env.open.SPRING_CLOUD_CONFIG_ENABLED | 是否启用配置中心
env.open.SPRING_CLOUD_CONFIG_URI | 配置中心地址
env.open.SPRING_DATASOURCE_URL | 数据库连接地址
env.open.SPRING_DATASOURCE_USERNAME | 数据库用户名
env.open.SPRING_DATASOURCE_PASSWORD | 数据库密码
metrics.path | 收集应用的指标数据路径
metrics.group| 性能指标应用分组
logs.parser | 日志收集格式
persistence.enabled | 是否启用持久化存储
persistence.existingClaim | 绑定的pvc名称
persistence.subPath| 持久化路径
service.enabled | 是否创建k8s service
service.type |  service类型
service.port | service端口
service.name | service名称
ingress.enabled | 是否创建k8s ingress
resources.limits | k8s中容器能使用资源的资源最大值
resources.requests | k8s中容器使用的最小资源需求